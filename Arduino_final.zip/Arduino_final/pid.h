const int RegulationRate = 800;   // time in ms between PID regulation steps

//****** PID regulation VARIABLES *******

//variables of the controller
double nFlowDifference;             
double ep, ei, ed;
double lastError;

double nPumpVoltage;      //drive the pump with this voltage amplitude
double nPumpFrequency;    //drive the pump with this frequency
byte PumpFrequency;       //the pump frequency in bytes

unsigned long nTimeStamp = 1;    //a time counter
int Case;                        //1,2,3 or 4---> according to the targeted flowrate

float K;   //a constant obtained by experimental syntonization of the controler
float Kp;  //proportional constant              
float Ki;  //integral constant
float Kd;  //derivative constant

//******* END OF VARIABLES *************

//******** FUNCTIONS *******************

void input(){  
  //This function sets Pumpfrequency, the Case and controller parameters according to targeted flowrate
  if(incValue > 0 && incValue <= 100){                               
    Case = 1;
    PumpFrequency = 0x01;                           //7,81 Hz
    K=4.5;
    Kp=1.0/K;
    Ki=1.0/K;
    Kd=1.0/K;
  }
  else if(incValue > 100 && incValue <= 250){
    Case = 2;
    PumpFrequency = 0x04;                           //31,25 Hz 
    K=9.2;
    Kp=1.0/K;
    Ki=0.8/K;
    Kd=0.5/K;
  }
  else if(incValue > 250 && incValue <= 500){
    Case = 3;
    PumpFrequency = 0x08;                           //62.50 Hz
    K=20.7;
    Kp=1.0/K;
    Ki=1.0/K;
    Kd=1.0/K;
  }
  else if(incValue > 500 /*&& incValue <= 1000*/){
    Case = 4;
    PumpFrequency = 0x0C;                           //93.75 Hz
    K=24.0;
    Kp=1.0/K;
    Ki=1.0/K;
    Kd=1.0/K;
  }
  nPumpFrequency = PumpFrequency*7.8125;
  Lowdriver_setfrequency(nPumpFrequency);      //drive the pump with the selected frequency
}

void changeCase(){
  //This function sets Pumpfrequency and controller parameters according to the Case 1,2,3 or 4
  //It is called when the frequency needs to be increased due to voltage saturation
  if(Case == 1){                              
    PumpFrequency = 0x01;                           //7,81 Hz
    K=4.5;
    Kp=1.0/K;
    Ki=1.0/K;
    Kd=1.0/K;
  }
  else if(Case ==2){
    PumpFrequency = 0x04;                           //31,25 Hz 
    K=9.2;
    Kp=1.0/K;
    Ki=0.8/K;
    Kd=0.5/K;
  }
  else if(Case ==3){
    PumpFrequency = 0x08;                           //62.5 Hz
    K=20.7;
    Kp=1.0/K;
    Ki=1.0/K;
    Kd=1.0/K;
  }
  else if(Case ==4){
    PumpFrequency = 0x0C;                           //93.75 Hz
    K=24.0;
    Kp=1.0/K;
    Ki=1.0/K;
    Kd=1.0/K;
  }
  nPumpFrequency = PumpFrequency*7.8125;
  Lowdriver_setfrequency(nPumpFrequency);           //drive the pump with the selected frequency
}

void pid_regulation(){              
  // PID-regulation Function
  delay(100);                                      
  nTimeStamp++;    
  flowAverage = readFlow();                         //read the flow rate from the sensor
  
  if((nTimeStamp%((RegulationRate/100)-1))==0){     //apply the PID controller each 800 ms
    nFlowDifference = (incValue - flowAverage);     //the error signal is the difference between the targeted flowrate and the real one
    ep = nFlowDifference;                           //proportional error signal
    ei += ep;                                       //integral error signal (dt=1)
    ed = ep - lastError;                            //derivative error signal (dt=1)
    lastError = ep;                                 //save the error value for the next regulation
    nPumpVoltage = (Kp*ep)+(Ki*ei)+(Kd*ed);         //the control signal----> the voltage of the pump
    nPumpVoltage = constrain(nPumpVoltage, 0,150);  //the Lowdriver a maximum of 150 Vpp 
    Lowdriver_setvoltage(nPumpVoltage);             //drive the pump with the computed voltage
 }
}

//*********** END OF FUNCTIONS ************
