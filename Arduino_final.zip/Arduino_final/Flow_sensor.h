#define I2C_SLF3S_ADRESS (0x08)        //Defaultadress for Sensirion SLF3S Flow-Sensor
#define SCALE_FACTOR_1300 500.0f       //flow rate scale value for the SLF3S-1300F (flow rate in ml/min)
//#define SCALE_FACTOR_0600 10000.0f   //flow rate scale value for the SLF3S-0600F (flow rate in ml/min)
#define SCALE_FACTOR_0600 10.0f        //flow rate scale value for the SLF3S-0600F (flow rate in ul/min)
#define SCALE_FACTOR_TEMP 200.0f       //temperature scale value
#define PN_1300 0x07030200             //product number of SLF3S-1300F 
#define PN_0600 0x07030300             //product number of SLF3S-0600F 

//******** FLOW SENSOR VARIABLES ********

float SCALE_FACTOR_FLOW;               //depends on the product: SLF3S-1300F or SLF3S-0600F 

//variables for the flow rate
uint16_t sensor_flow_value;
int16_t signed_flow_value; 
float scaled_flow_value;

//variables for the temperature
uint16_t sensor_temp_value;
int16_t signed_temp_value; 
float scaled_temp_value;

//variables for the signaling flags
uint8_t signaling_flag_msb;
uint8_t signaling_flag_lsb;
uint8_t air_in_line_flag;  
uint8_t high_flow_flag;
uint8_t exponential_smoothing_active;
uint8_t air_in_line_flag_value;  
uint8_t high_flow_flag_value;
uint8_t exponential_smoothing_active_value;

//*********** END OF VARIABLES ************

//*********** FUNCTIONS *******************

bool startFlowMeasurement(void) {
  uint32_t ProductNumber;
  int ret;
  if ((sensors & 0x02)>0) {   //Check if sensor isn't already running
    //Stop continuous measurement
    Wire.beginTransmission(I2C_SLF3S_ADRESS);
    Wire.write(0x3F);
    Wire.write(0xF9);
    ret = Wire.endTransmission();  
  }
  delay(100);
  //Read Product Identifier and Serial number
  Wire.beginTransmission(I2C_SLF3S_ADRESS);
  Wire.write(0x36);
  Wire.write(0x7C);
  ret = Wire.endTransmission();

  Wire.beginTransmission(I2C_SLF3S_ADRESS);
  Wire.write(0xE1);
  Wire.write(0x02);
  ret = Wire.endTransmission();

  Wire.requestFrom(I2C_SLF3S_ADRESS, 6);
  delay(50);
  ProductNumber = Wire.read();
  ProductNumber = ProductNumber<<8 | Wire.read();
  Wire.read();  //CRC
  ProductNumber = ProductNumber<<8 | Wire.read();
  ProductNumber = ProductNumber<<8 | Wire.read();
  Wire.read();  //CRC
  ret = Wire.endTransmission();
  
//  Serial.print("PN: ");
//  Serial.println(ProductNumber, HEX);
  
  if ((ProductNumber & 0xFFFFFF00) == PN_1300) {  
    SCALE_FACTOR_FLOW = SCALE_FACTOR_1300;
  } else if ((ProductNumber & 0xFFFFFF00) == PN_0600) {  
    SCALE_FACTOR_FLOW = SCALE_FACTOR_0600;
  } else {
    SCALE_FACTOR_FLOW = 1;
    return false;
  }
  // Soft reset the sensor
  Wire.beginTransmission(I2C_SLF3S_ADRESS);
  Serial.println("soft reset the sensor");
  Wire.write(0x06); 
  ret = Wire.endTransmission();
  delay(100); // wait long enough for chip reset to complete

  //Start continuous measurement
  Wire.beginTransmission(I2C_SLF3S_ADRESS);  //starting measurement 
  Wire.write(0x36); //Start continuous measurement
  Wire.write(0x08); //Water calibration (0x15 for IPA)
  ret = Wire.endTransmission();
  return true;
}

void stopFlowMeasurement() {
  int ret;
  if ((sensors & 0x02)>0) {
    //Stop continuous measurement
    Wire.beginTransmission(I2C_SLF3S_ADRESS);
    Wire.write(0x3F);
    Wire.write(0xF9);
    ret = Wire.endTransmission();  
    delay(100);
  }
}

bool startFlowMeasurement_simple(void) {  
  // Soft reset the sensor
  Wire.beginTransmission(I2C_SLF3S_ADRESS);
  Wire.write(0x06); 
  Wire.endTransmission();
  delay(50); // wait long enough for chip reset to complete

  //Start continuous measurement
  Wire.beginTransmission(I2C_SLF3S_ADRESS);  //starting measurement 
  Wire.write(0x36); //Start continuous measurement
  Wire.write(0x08); //Water calibration (0x15 for IPA)
  return (Wire.endTransmission()!=2); //0=success; 3 is already running; 2 is no response
}

float readFlow(void) { 
  //This function reads the sensor output and returns the flow rate value
  
  Wire.requestFrom(I2C_SLF3S_ADRESS, 3);    //Wire.requestFrom(address, quantity of bytes)
  while (Wire.available() < 3) { }
  sensor_flow_value  = Wire.read() << 8;    // read the MSB of the flow rate
  sensor_flow_value |= Wire.read();         // read the LSB of the flow rate
  Wire.read();  //CRC
  
  signed_flow_value = (int16_t) sensor_flow_value;
  scaled_flow_value = ((float) signed_flow_value) / SCALE_FACTOR_FLOW;    

  return scaled_flow_value;
}

float readTemp(void) {      
  //This function reads the sensor output and returns the temperature value 
  
  Wire.requestFrom(I2C_SLF3S_ADRESS, 6);    //Wire.requestFrom(address, quantity of bytes)
  while (Wire.available() < 6) { }

  Wire.read();  //MSB from the flow rate
  Wire.read();  //LSB from the flow rate
  Wire.read();  //CRC

  sensor_temp_value  = Wire.read() << 8;    // read the MSB of the temperature
  sensor_temp_value |= Wire.read();         // read the LSB of the temperature
  Wire.read();  //CRC
  
  signed_temp_value = (int16_t) sensor_temp_value;
  scaled_temp_value = ((float) signed_temp_value) / SCALE_FACTOR_TEMP;    
  
  return scaled_temp_value;
}

float readAirInLine(void) {                 
  //This function reads the sensor output and returns the air_in_line_flag_value 
  //(1 if there is air in the system and 0 if not) 
  
  Wire.requestFrom(I2C_SLF3S_ADRESS, 9);   //Wire.requestFrom(address, quantity of bytes)
  while (Wire.available() < 9) {            
  }
  sensor_flow_value  = Wire.read() << 8;    // read the MSB of the flow rate
  sensor_flow_value |= Wire.read();         // read the LSB of the flow rate
  Wire.read();  //CRC

  sensor_temp_value  = Wire.read() << 8;    // read the MSB of the temperature
  sensor_temp_value |= Wire.read();         // read the LSB of the temperature
  Wire.read();  //CRC  

  signaling_flag_msb = Wire.read();         // read the MSB of the signaling flag
  signaling_flag_lsb = Wire.read();         // read the LSB of the signaling flag
  Wire.read();  //CRC

  air_in_line_flag = 0b0000001&signaling_flag_lsb;               //bit0
  high_flow_flag = 0b0000010&signaling_flag_lsb;                 //bit1
  exponential_smoothing_active = 0b0100000&signaling_flag_lsb;   //bit5

  air_in_line_flag_value = air_in_line_flag;
  high_flow_flag_value = high_flow_flag >> 1;
  exponential_smoothing_active_value = exponential_smoothing_active >> 5;
  
  return air_in_line_flag_value;
}

//*********** END OF FUNCTIONS ************
